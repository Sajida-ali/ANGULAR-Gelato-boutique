export class Anita{
    code:number;
    prodcutName:string;
    img : string;
    flavor:string;
    price : number;  
    constructor(code:number, prodcutName:string , img:string,flavor:string,price:number){
        this.code=code;
        this.prodcutName=prodcutName;
        this.img=img;
        this.flavor=flavor;
        this.price=price;
    }

}
  