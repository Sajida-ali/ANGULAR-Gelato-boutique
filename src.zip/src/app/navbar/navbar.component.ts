import { Component, OnInit ,ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
  encapsulation: ViewEncapsulation.Emulated 

})
export class NavbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  logo='assets/img/logo.jpg'
}
